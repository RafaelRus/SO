//
// Created by Alberto on 22/3/18.
//

#ifndef ARCPORT_PLANE_H
#define ARCPORT_PLANE_H


struct plane {
    int id_number;
    int time_action;
    int action;
    int last_flight; 
};


#endif //ARCPORT_PLANE_H
