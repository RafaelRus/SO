#include <stdio.h>
#include <stdlib.h>
#include "queue.h"
#include <string.h>

#include "plane.h"

/* Array de struct plane's */
struct plane* queue;
/*
	Contadores de tamaño maximo y numero de elementos.
	Facilitan algunos metodos
*/
int numElems;
int queueSize;
/*
	Indices sobre los que se realizaran las proximas operaciones.
	Necesarios para hacer que la cola sea circular
*/
int read = 0;
int write = 0;

/*To create a queue*/
int queue_init(int size){
	/* Como el tamaño recibido esta en bytes se utiliza directamente */
    queue = (struct plane*) malloc(size);
    if(queue == NULL){
		printf("ERROR No se ha podido crear la cola\n");
		exit(-1);
    }
    /* Para calcular cuantos aviones "caben" en size bytes se divide */
    queueSize = size / sizeof(struct plane);
    numElems = 0;
    printf("[QUEUE] Buffer initialized\n");
    return 0;
}

/* To Enqueue an element*/
int queue_put(struct plane* x) {
    if(numElems >= queueSize){
		printf("ERROR Cola llena. No se añadirá\n");
		free(queue);
		exit(-1);
    }
    queue[write] = *x;
    numElems++;
    /* Incremento del indice que hace que la cola sea circular */
    write = (write + 1) % queueSize;
    printf("[QUEUE] Storing plane with id %d\n", x->id_number);
    return 0;
}


/* To Dequeue an element.*/
struct plane* queue_get(void) {
    if(numElems == 0){
		printf("ERROR Cola vacia\n");
		free(queue);
		exit(-1);
    }

    struct plane* out = &queue[read];
    numElems--;
    /* Incremento del indice que hace que la cola sea circular */
    read = (read + 1) % queueSize;
    printf("[QUEUE] Getting plane with id %d\n", out->id_number);
    return out;
}


/*To check queue state*/
int queue_empty(void){
    return numElems == 0;
}

/*To check queue state*/
int queue_full(void){
    return numElems == queueSize;
}

/*To destroy the queue and free the resources*/
int queue_destroy(void){
	if(!queue_empty()){
		printf("ERROR Queue was destroyed while storing planes\n");
		exit(-1);
	}
    free(queue);
    return 0;
}
