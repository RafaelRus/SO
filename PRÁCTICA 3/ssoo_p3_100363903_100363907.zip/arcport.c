#include <stdio.h>
#include <stdlib.h>
#include "queue.h"
#include <pthread.h>
#include <unistd.h>
		
/* 
	Si NUM_TRACKS se pone a 1 y se ejecuta en modo multipista
	no de veran diferencias con el modo estandar de ejecucion.
	NUM_TRACKS cualquier valor mayor que 2. El programa se
	ejecutara con ese numero de pistas.
*/
#define NUM_TRACKS 2	

/* Declaracion del mutex y las variables condicion */
pthread_mutex_t mut_id;
pthread_cond_t cond_full_id;		//bloquea cuando la cola esta llena y se trata de escribir
pthread_cond_t cond_empty_id;		//bloquea cuando la cola esta vacia y se trata de leer
pthread_cond_t cond_last_plane_id;	//bloquea antes de insertar el ultimo avion si es necesario

/* Para asignar los id de los aviones */
int contador_id = 0;
/*
	Contadores para aviones. Son arrays para poder guardar
	el numero de aviones que procesa cada pista.
*/
int contador_despegue[NUM_TRACKS];	
int contador_aterrizaje[NUM_TRACKS];


/* PARAMETROS GLOBALES (LOS THREADS SOLO LOS LEEN) */
int n_planes_takeoff;
int time_to_takeoff;
int n_planes_to_arrive;
int time_to_arrive;
int size_of_buffer;
int exe_mode;

/*
	Variables booleanas que junto con las variables
	condicion sirven para coordinar cuando los hilos
	pueden escribir o leer el ultimo avion sin entrar
	en un interbloqueo.
*/
int trackboss_alive = 1;
int radar_alive = 1;
int last_plane_processed = 0;

void print_banner()
{
	printf("\n*****************************************\n");
	printf("Welcome to ARCPORT - The ARCOS AIRPORT.\n");
	printf("*****************************************\n\n");
}

/*
	Hilo de TRACKBOSS. Crea tantos aviones como diga
	la variable n_planes_takeoff y los va insertando
	en el buffer circular.
*/
void* threadJefePista(void* x){
	int i;
	for (i = 0; i < n_planes_takeoff; i++){
		struct plane newPlane;

		pthread_mutex_lock(&mut_id);

		/* Region critica. Se accede al contador_id que es variable global */

		newPlane.id_number = contador_id;
		contador_id++;

		printf("[TRACKBOSS] Plane with id %d checked\n", newPlane.id_number);

		pthread_mutex_unlock(&mut_id);

		/* Calculo de los parametros del avion que no son el id (ya tomado arriba) */

		newPlane.time_action = time_to_takeoff;
		newPlane.action = 0; 			//0 para despegue

		if(newPlane.id_number < (n_planes_takeoff + n_planes_to_arrive)-1)
			newPlane.last_flight = 0;	//No es ultimo vuelo
		else
			newPlane.last_flight = 1;	//Es ultimo vuelo

		pthread_mutex_lock(&mut_id);

		/*
			Si el vuelo que se va a insertar es el ultimo y el otro
			hilo (que nunca va a poder escribir el ultimo avion ya que
			dicho avion lo tiene este hilo) todavia tiene aviones por
			escribir, se le deja terminar.
			Si el otro hilo ya ha terminado, se continua.
		*/

		if(newPlane.last_flight && radar_alive)
			pthread_cond_wait(&cond_last_plane_id, &mut_id);

		/*
			Si la cola ya esta llena y se trata de escribir se producira
			un fallo. Se bloquea este hilo hasta que se cree un espacio 
			disponible para inserccion.
		*/

		while(queue_full())
			pthread_cond_wait(&cond_full_id, &mut_id);

		/* Se añade el avion a la cola */
		queue_put(&newPlane);

		printf("[TRACKBOSS] Plane with id %d ready to take off\n", newPlane.id_number);

		/*
			Como la cola ya no esta vacia se despierta a todos los hilos
			que estaban bloqueados porque iban a leer de la cola vacia.
		*/
		pthread_cond_broadcast(&cond_empty_id);
		
		pthread_mutex_unlock(&mut_id);

	}

	/*
		Cuando este hilo va a terminar se escribe la variable global
		para informar de esto y se liberan los hilos que estaban esperando
		para insertar el ultimo avion (si los hubiese). Despues el hilo termina.
	*/
	pthread_mutex_lock(&mut_id);
	trackboss_alive = 0;
	pthread_mutex_unlock(&mut_id);

	pthread_cond_signal(&cond_last_plane_id);

	pthread_exit(NULL);
}

/*
	Hilo de RADAR. Crea tantos aviones como diga
	la variable n_planes_to_arrive y los va insertando
	en el buffer circular.
*/
void* threadRadar(void* x){

	int i;
	for (i = 0; i < n_planes_to_arrive; i++){
		struct plane newPlane;

		pthread_mutex_lock(&mut_id);

		/* Region critica. Se accede al contador_id que es variable global */

		newPlane.id_number = contador_id;
		contador_id++;

		printf("[RADAR] Plane with id %d detected!\n", newPlane.id_number);	

		pthread_mutex_unlock(&mut_id);

		/* Calculo de los parametros del avion que no son el id (ya tomado arriba) */

		newPlane.time_action = time_to_arrive;
		newPlane.action = 1; 			//1 para aterrizaje

		
		if(newPlane.id_number < (n_planes_takeoff + n_planes_to_arrive)-1){
			newPlane.last_flight = 0;	//No es ultimo vuelo	
			//printf("No es ultimo vueloRadar\n");
			
		}else{
			newPlane.last_flight = 1;	//Es ultimo vuelo
			//printf("Ultimo vuelo creado\n");
		}	

		
		
		pthread_mutex_lock(&mut_id);

		/*
			Si el vuelo que se va a insertar es el ultimo y el otro
			hilo (que nunca va a poder escribir el ultimo avion ya que
			dicho avion lo tiene este hilo) todavia tiene aviones por
			escribir, se le deja terminar.
			Si el otro hilo ya ha terminado, se continua.
		*/

		if(newPlane.last_flight && trackboss_alive)
			pthread_cond_wait(&cond_last_plane_id, &mut_id);

		/*
			Si la cola ya esta llena y se trata de escribir se producira
			un fallo. Se bloquea este hilo hasta que se cree un espacio 
			disponible para inserccion.
		*/

		while(queue_full())
			pthread_cond_wait(&cond_full_id, &mut_id);

		/* Se añade el avion a la cola */
		queue_put(&newPlane);

		printf("[RADAR] Plane with id %d ready to land\n", newPlane.id_number);

		/*
			Como la cola ya no esta vacia se despierta a todos los hilos
			que estaban bloqueados porque iban a leer de la cola vacia.
		*/
		pthread_cond_broadcast(&cond_empty_id);

		pthread_mutex_unlock(&mut_id);

	}

	/*
		Cuando este hilo va a terminar se escribe la variable global
		para informar de esto y se liberan los hilos que estaban esperando
		para insertar el ultimo avion (si los hubiese). Despues el hilo termina.
	*/
	pthread_mutex_lock(&mut_id);
	radar_alive = 0;
	pthread_mutex_unlock(&mut_id);

	pthread_cond_signal(&cond_last_plane_id);

	pthread_exit(NULL);
}

void* threadTorreControl(void* x){	
	struct plane* selectedPlane;
	
	do {
		pthread_mutex_lock(&mut_id);

		/*
			Si la cola esta vacia y se trata de leer se producira
			un fallo. Se bloquea este hilo hasta que se creen uno
			o mas aviones.
		*/
		while(queue_empty()){
			printf("[CONTROL] Waiting for planes in empty queue\n");
			pthread_cond_wait(&cond_empty_id, &mut_id);
		}

		/* Se obtiene el avion de la lista */
		selectedPlane = queue_get();

		/*
			Como la cola ya no esta llena se despierta a todos los hilos
			que estaban bloqueados porque iban a desbordar la cola si escribian.
		*/
		pthread_cond_broadcast(&cond_full_id);

		
		if(selectedPlane->action == 0)
			printf("[CONTROL] Putting plane with id %d in track\n", selectedPlane->id_number);
		else
			printf("[CONTROL] Track is free for plane with id %d\n", selectedPlane->id_number);


		/* Si es el ultimo avion entonces se imprimie un mensaje especial */
		if(selectedPlane->last_flight)
			printf("[CONTROL] After plane with id %d the aiport will be closed\n", selectedPlane->id_number);

		/* Se incrementan los contadores globales */
		if(selectedPlane->action == 0){
			printf("[CONTROL] Plane with id %d took off after %d seconds\n",selectedPlane->id_number, selectedPlane->time_action);
			contador_despegue[0]++;
		}else{
			printf("[CONTROL] Plane with id %d landed in %d seconds\n",selectedPlane->id_number, selectedPlane->time_action);
			contador_aterrizaje[0]++;
		}

		/* Se libera el cerrojo del mutex */
		pthread_mutex_unlock(&mut_id);

	/* Si el avion procesado es el ultimo se finaliza el bucle y el hilo */
	} while(!selectedPlane->last_flight);
	pthread_exit(NULL);
}

void* threadMultiplesTorresControl(void* x){	
	long towerId = (long) x;
	struct plane* selectedPlane;

	do {

		pthread_mutex_lock(&mut_id);

		/*
			Si la cola esta vacia y se trata de leer se producira
			un fallo. Se bloquea este hilo hasta que se creen uno
			o mas aviones.
		*/
		while(queue_empty()){
			/*
				Si el ultimo avion ya ha sido procesado (por otra torre)
				el proceso termina dado que se sabe que la cola permanecera
				vacia y el hilo no saldria nunca de la variable condicion.
			*/
			if(last_plane_processed){
				pthread_mutex_unlock(&mut_id);
				pthread_exit(NULL);
			}
			printf("[CONTROL_%ld] Waiting for planes in empty queue\n", towerId);
			pthread_cond_wait(&cond_empty_id, &mut_id);
		}

		/* Se obtiene el avion de la lista */
		selectedPlane = queue_get();

		/*
			Como la cola ya no esta llena se despierta a todos los hilos
			que estaban bloqueados porque iban a desbordar la cola si escribian.
		*/
		pthread_cond_broadcast(&cond_full_id);


		if(selectedPlane->action == 0)
			printf("[CONTROL_%ld] Putting plane with id %d in track\n", towerId, selectedPlane->id_number);
		else
			printf("[CONTROL_%ld] Track is free for plane with id %d\n", towerId, selectedPlane->id_number);

		/*
			Si es el ultimo vuelo se imprime un mensaje especial y se informa
			a traves de la variable booleana a los demas hilos de que deben
			terminar porque no les queda trabajo por hacer.
		*/
		if(selectedPlane->last_flight){
			printf("[CONTROL_%ld] After plane with id %d the aiport will be closed\n", towerId, selectedPlane->id_number);
			last_plane_processed = 1;
		}


		//sleep(selectedPlane->time_action);

		//pthread_mutex_lock(&mut_id);

		if(selectedPlane->action == 0){
			printf("[CONTROL_%ld] Plane with id %d took off after %d seconds\n", towerId, selectedPlane->id_number, selectedPlane->time_action);
			contador_despegue[towerId]++;
		}else{
			printf("[CONTROL_%ld] Plane with id %d landed in %d seconds\n",towerId, selectedPlane->id_number, selectedPlane->time_action);
			contador_aterrizaje[towerId]++;
		}
		
		/* Se libera el cerrojo del mutex */
		pthread_mutex_unlock(&mut_id);

	/* Si el avion procesado es el ultimo se finaliza el bucle y el hilo */
	} while(!selectedPlane->last_flight);
	pthread_exit(NULL);
}

int main(int argc, char ** argv) {
	long i;
	int j;
	int validParams = 1;

	/* Inicializacion de los contadores */
	for (i = 0; i < NUM_TRACKS; i++){
		contador_aterrizaje[i] = 0;
		contador_despegue[i] = 0;
	}

	/*
		Control de parametros correctos. Solo se admiten 0, 4 o 5
		parametros dependiendo del modo de ejecucion deseado.
		Estos parametros siempre han de ser numeros enteros positivos.
		El quinto parametro (si lo hubiera) debe ser estrictamente igual a 1.
		El valor cero esta admitido en todos los campos (excepto el ultimo).
	*/
	if(argc == 1){
		n_planes_takeoff = 4;
		time_to_takeoff = 2;
		n_planes_to_arrive = 3;
		time_to_arrive = 3;
		size_of_buffer = 6;
		exe_mode = 0;

	}else if(argc == 7 && *argv[6] == '1'){

		for(i = 1; i < 6 && validParams; i++)
			for(j = 0; j < argv[i+1] - argv[i]-1 && validParams; j++)
				if(argv[i][j] < '0' || argv[i][j] > '9')
					validParams = 0;
	
	}else if(argc == 6){
		for(i = 1; i < 5 && validParams; i++)
			for(j = 0; j < argv[i+1] - argv[i]-1 && validParams; j++)
				if(argv[i][j] < '0' || argv[i][j] > '9')
					validParams = 0;
	}else{
		printf("usage 1: ./arcport\n");
		printf("usage 2: ./arcport <n_planes_takeoff> <time_to_takeoff> <n_planes_to_arrive> <time_to_arrive> <size_of_buffer>\n");
		printf("usage 3: ./arcport <n_planes_takeoff> <time_to_takeoff> <n_planes_to_arrive> <time_to_arrive> <size_of_buffer> <exe_mode>\n");
		exit(-1);
	}


	/*
		Si los parametros son validos y se han especificado, se asignan.
		Si no son validos se devuelve un error
	*/
	if(!validParams){

		printf("ERROR Invalid Params\n");
		exit(-1);
	}else if(argc != 1){
		n_planes_takeoff = atoi(argv[1]);
		time_to_takeoff = atoi(argv[2]);
		n_planes_to_arrive = atoi(argv[3]);
		time_to_arrive = atoi(argv[4]);
		size_of_buffer = atoi(argv[5]);
		if(argc == 6)
			exe_mode = 0;
		else
			exe_mode = 1;
	}

	/* 
		Se inicializa la cola con el tamaño descrito en
		la variable size_of_buffer.
		Esta variable esta expresada en numero de aviones
		pero la funcion queue_init recibe tamaño en bytes.
		Se multiplica por el tamaño de un avion para hacer
		la conversion.
	*/
	print_banner();
	queue_init(size_of_buffer * sizeof(struct plane));

	/*
		Se definen los hilos necesarios y se inicializan las
		variables condicionales que se habian definido arriba.
	*/
	pthread_t jefePista, radar;
	pthread_t torresControl[NUM_TRACKS];
	
	pthread_mutex_init(&mut_id, NULL);
	pthread_cond_init(&cond_empty_id, NULL);
	pthread_cond_init(&cond_full_id, NULL);
	pthread_cond_init(&cond_last_plane_id, NULL);

	/*
		Si el modo de ejecucion es estandar solo se crea una torre
		de control en la posicion 0 del array.
		Si el modo de ejecucion es multipista se crean tantas torres
		de control como sea NUM_TRACKS
	*/
	if(exe_mode == 0)
		pthread_create(&torresControl[0], NULL, threadTorreControl, NULL);
	else
		for(i = 0; i < NUM_TRACKS; i++)
			pthread_create(&torresControl[i], NULL, threadMultiplesTorresControl, (void*) i);
	
	pthread_create(&jefePista, NULL, threadJefePista, NULL);
	pthread_create(&radar, NULL, threadRadar, NULL);


	/* El proceso principal espera por la finalizacion de todos los hilos */
	pthread_join(jefePista, NULL);
	pthread_join(radar, NULL);
	if(exe_mode == 0){
		pthread_join(torresControl[0], NULL);
	}
	else{
		for(i = 0; i < NUM_TRACKS; i++)
			pthread_join(torresControl[i], NULL);
	}

	/* Se liberan todos los recursos creados y se "cierra" el aeropuerto */
	pthread_mutex_destroy(&mut_id);
	pthread_cond_destroy(&cond_empty_id);
	pthread_cond_destroy(&cond_full_id);
	pthread_cond_destroy(&cond_last_plane_id);
	
	queue_destroy();
	printf("Airport Closed!\n");


	/* Se imprimen los contadores obtenidos tras la ejecucion en el fichero resumen */
	FILE * fd = fopen("resume.air", "w");
	//int fd = open("resume.air", O_CREAT | O_TRUNC | O_WRONLY, 00666);

	if(fd == NULL){
		printf("ERROR out file cannot be created or opened\n");
		exit(-1);
	}

	int totalTakeoff = 0;
	int totalLand = 0;

	for(i = 0; i < NUM_TRACKS; i++){
		totalTakeoff += contador_despegue[i];
		totalLand += contador_aterrizaje[i];
	}

	fprintf(fd, "\tTotal number of planes processed: %d\n", totalLand + totalTakeoff);
	fprintf(fd, "\tNumber of planes landed: %d\n", totalLand);
	fprintf(fd, "\tNumber of planes taken off: %d\n", totalTakeoff);

	if(exe_mode == 1)
		for(i = 0; i < NUM_TRACKS; i++)
			fprintf(fd, "\tNumber of planes processed in track %ld: %d\n", i, contador_aterrizaje[i] + contador_despegue[i]);


	fclose(fd);
	return 0;
}
