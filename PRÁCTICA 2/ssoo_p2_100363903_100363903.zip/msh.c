/*-
 * msh.c
 *
 * Minishell C source
 * Show how to use "obtain_order" input interface function
 *
 * THIS FILE IS TO BE MODIFIED
 */

#include <stddef.h>			/* NULL */
#include <stdio.h>			/* setbuf, printf */
#include <stdlib.h>			
#include <unistd.h>
#include <string.h>

#include <sys/wait.h>		
#include <fcntl.h>			/*open*/
#include <time.h>


time_t start_time;

extern int obtain_order();		/* See parser.y for description */

struct command{
  // Store the number of commands in argvv
  int num_commands;
  // Store the number of arguments of each command
  int *args;
  // Store the commands 
  char ***argvv;
  // Store the I/O redirection
  char *filev[3];
  // Store if the command is executed in background or foreground
  int bg;
};

/*
	Definicion de lista ligada simple para guardar los PIDs de procesos en 
	backgound, para despues garantizar su terminacion. 	
*/

// Estructura que almacena el pid de un proceso en
// background y un puntero al siguiente "nodo" de la lista.
typedef struct node_t{
	int bgPid;
	struct node_t* next;
}node_t;

//Funcion para anadir nodos con pids a la lista ligada.
node_t* addNode(int newBgPid, node_t* last){
	node_t* newNode = (node_t*) malloc(sizeof(node_t));
	newNode -> bgPid = newBgPid;
	newNode -> next = NULL;
	last -> next = newNode;
	return last;
}
/*
Funcion para vaciar la lista simple y liberar la memoria
reservada por addNode. Se incluyo 
la funcion waitpid para vericar que no se pueda salir de la 
minishell si aun hay algun proceso ejecutando en segundo plano.

*/
void deleteListAndWait(node_t* node){
	if(node == NULL)
		return;
	if(node -> next == NULL){
		waitpid(node -> bgPid, NULL, 0);
		free(node);
	}
	else
		deleteListAndWait(node -> next);

}

void free_command(struct command *cmd)
{
   if((*cmd).argvv != NULL){
     char **argv;
     for (; (*cmd).argvv && *(*cmd).argvv; (*cmd).argvv++)
     {
      for (argv = *(*cmd).argvv; argv && *argv; argv++)
      {
        if(*argv){
           free(*argv);
           *argv = NULL;
        }
      }
     }
   }
   free((*cmd).args);
   int f;
   for(f=0;f < 3; f++)
   {
     free((*cmd).filev[f]);
     (*cmd).filev[f] = NULL;
   }
}

void store_command(char ***argvv, char *filev[3], int bg, struct command* cmd)
{
  int num_commands = 0;
  while(argvv[num_commands] != NULL){
    num_commands++;
  }

  int f;
  for(f=0;f < 3; f++)
  {
    if(filev[f] != NULL){
      (*cmd).filev[f] = (char *) calloc(strlen(filev[f]) , sizeof(char));
      strcpy((*cmd).filev[f], filev[f]);
    }
  }  

  (*cmd).bg = bg;
  (*cmd).num_commands = num_commands;
  (*cmd).argvv = (char ***) calloc((num_commands+1) , sizeof(char **));
  (*cmd).args = (int*) calloc(num_commands , sizeof(int));
  int i;
  for( i = 0; i < num_commands; i++){
    int args= 0;
    while( argvv[i][args] != NULL ){
      args++;
    }
    (*cmd).args[i] = args;
    (*cmd).argvv[i] = (char **) calloc((args+1) , sizeof(char *));
    int j;
    for (j=0; j<args; j++) {
       (*cmd).argvv[i][j] = (char *)calloc(strlen(argvv[i][j]) , sizeof(char));
       strcpy((*cmd).argvv[i][j], argvv[i][j] );
    }
  }
}

//	1.1.3 Desarrollo de minishell

/*
	b) My time: comando para mostrar el tiempo que lleva ejecutando la minshell indicando horas,
				minutos y segundos con el mensaje "Uptime: X h. Y min. Z s. ."
*/

void mytime(){

	/*
		Variable que guarda el tiempo de diferencia entre el inicio de la minishell en segundos
		y el 1 de enero de 1970 (tiempo UNIX), tambien en segundos.
		Usando esta variable y el modulo apropiado para cada
		campo se pudo calcular el tiempo en "up" de la minishell. 
	*/ 

	int current_time = (int) difftime(time(NULL), start_time);

	int hour, minute, second;

	hour = current_time / 3600;
	minute = (current_time % 3600)/60;
	second = (current_time % 60);

	printf("Uptime: %d Hours, %d Minutes, %d Seconds\n",hour, minute, second);

}

/*

	c) mycd: Comando que cambia el directorio actual al especificado como argumento. Si no se recibe
			  argumento alguno, se cambia al directorio home. 
			  Imprime el en pantalla el directorio al que se ha cambiado.

*/

void mycd(char* newDirectory){
	
	//En caso de no recibir parametro alguno se hace e cambio al directorio home.
	if(newDirectory == NULL){
		chdir(getenv("HOME"));
		printf("%s\n",getenv("HOME"));
	}else{

		//Si se recibe un directorio raiz, se accede directamente.
		if(newDirectory[0] == '/'){
			if(chdir(newDirectory)){
			
				perror("");
				exit(-1);
			}else{
				printf("%s\n", newDirectory);
			}
		}
		//Si se omite el directorio raiz se concatena con la cadena recibida
		else{
		
			//Se reserva memoria para guardar el argumento recibido. 
			int size = 100;
			char* buffer = (char*) malloc(size);

		
			//Si el tamanio del buffer es insuficiente se hace un realloc para conseguir el tamanio necesario.
			while(getcwd(buffer, size) == NULL){
				size += 50;
				buffer = (char*) realloc(buffer, size);
			}
				if(sizeof(*buffer) - strlen(buffer) < sizeof(*newDirectory) + 1){
				
					buffer = (char*) realloc(buffer, sizeof(*newDirectory) + 1);
				}

				buffer = strcat(buffer, "/");
				buffer = strcat(buffer, newDirectory);

				//Si chdir regresa algo menor a 0 se produce un error y sale de la minishell.
				if(chdir(buffer) == -1){
					
					perror("");
					exit(-1);
				}else{
					printf("%s\n", buffer);
			}
			//Se libera el buffer reservado para el argumento de mycd
			free(buffer);
		}

		
	}

}

/*
	a) Mandato interno: exit
	Libera la memoria utilizada para la creacion de lista de PIDS ligada,
	el struct de los comandos y cierra la minishell.
	Imprime el mensaje de despedida "Goodbye!"

*/

void myExit(struct command history[], int* globalNumCommands, node_t* first){
	int i;
	for(i = 0; i < 20; i++){
    	if(i < *globalNumCommands%20)
    		free_command(&history[i]);
    }

    deleteListAndWait(first);
    printf("Goodbye!\n");
    exit(0);
}

//Recibe un struct command y lo escribe por completo

void print_command(struct command* cmd){
	int i = 0, j = 0;
	char* redir[] = {"<", ">", ">&"};
	/*
		Mientras el puntero del arreglo que contiene los parametros 
		es diferente de null se realiza la impresion de los comandos.
		Se tiene un bucle anidado para imprimir la "matriz" que contiene
		dichos comandos.
	*/
	while(cmd->argvv[i] != NULL){
		if(i != 0)
				printf("| ");
		while(cmd->argvv[i][j] != NULL){
			printf("%s ", cmd->argvv[i][j]);
			j++;
		}

		j = 0;
		i++;
	}

	for (i = 0; i < 3; ++i) {
		if(cmd->filev[i] != NULL)
			printf("%s %s ", redir[i], cmd->filev[i]);
	}

	if(cmd->bg == 1)
		printf(" &\n");
	else
		printf("\n");
}

int main(void)
{
	//Inicializacion necesaria para mytime
	start_time = time(NULL);

	//Inicializacion de nodos inicial y final para la lista ligada dinamica que guarda 
	//los pids. 
	node_t* first = NULL;
	node_t* last = NULL;

	

	char ***argvv;
	/*int command_counter;*/
	int num_commands;
	/*int args_counter;*/
	char *filev[3];
	int bg;
	int ret;

	setbuf(stdout, NULL);			/* Unbuffered */
	setbuf(stdin, NULL);

	int pid = 0, status = 0;
	int p1[2] = {-1, -1};
	int p2[2] = {-1, -1};

	//Variables globales para control de la shell.
	int i;
	int j;
	int k;
	int fdaux;

	//Struct para guardar comandos.
	struct command history[20];
	//Variable global para llevar una cuenta de cuantos comandos se ha introducido.
    int globalNumCommands = 0;

	while (1) 
	{

		fprintf(stderr, "%s", "msh> ");	/* Prompt */
		ret = obtain_order(&argvv, filev, &bg);
		//Si se intenta hace un EOF a partir de crtl+d se llama la funcion myExit
		//para salir de la minishell solo si no hay procesos esperando
		if (ret == 0) myExit(history, &globalNumCommands, first);		/* EOF */
		if (ret == -1) continue;	/* Syntax error */
		num_commands = ret - 1;		/* Line */
		if (num_commands == 0) continue;	/* Empty line */
		
		//Control para mantener maximo numero de comandos menor a 3
    	if(num_commands > 3){
    		perror("Numero maximo de comandos es tres");
    		continue;
    	}

    	/*
	d) myhistory : almacena los ultimos 20 comandos introducidos en la minishell.
					Si se ejecuta sin parametros regresa los N comandos guardados si hay menos de 20, 
					si no se imprimen los 20 ultimos en orden cronologico.
					Solo puede recibir numeros como parametro y si lo recibe se corre el comando correspondiente 
					a la lista de "myhistory"
*/

    	if(!strcmp(argvv[0][0], "myhistory")){
    		if(argvv[0][1] == NULL && argvv[1] == NULL){	/*No hay parametro*/

    			
    			//Bucle para imprimir los ultimos 20 comandos almacenados 
    			if(globalNumCommands < 20){
    				for (i = 0; i < 20; ++i){
						if(i < globalNumCommands){
							printf("%d ", i);
							print_command(&history[i]);
						}
    				}
    			}else{
    				//Si la lista de comandos supera los 20 se utiliza el operador modulo para volver 
    				 //a comenzar la cuenta moviendo un puntero. 
    				//Impresion desde el puntero hasta el final.
    				k = 0;
    				for (i = globalNumCommands % 20; i < 20; ++i){
						printf("%d ", k);
						print_command(&history[i]);
						k++;
					}
					//Si la lista de comandos supera los 20 se utiliza el operador modulo para volver 
    				 //a comenzar la cuenta moviendo un puntero. 
    				//Impresion desde el principio hasta el puntero.
					for (i = 0; i < globalNumCommands % 20; ++i){
						printf("%d ", k);
						print_command(&history[i]);
						k++;
					}
				}
				//Regresa la minishell a solicitar un comando
    			continue;	/*Para evitar imprimir mensajes de error falsos*/

    		}else if(argvv[0][2] == NULL && argvv[1] == NULL){	/*Hay un parametro*/
    			//Flag para saber si el parametro ingresado con "Myhistory" es correcto 
    			int validParam = 0;
    			int contador = 0;
    			//Arreglo con los valores validos como parametro para "myhistory" 
    			char* valores[] = {"0","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19"};

    			while(!validParam && contador < 20){
    				if(strcmp(valores[contador], argvv[0][1]) == 0)
    					validParam = 1;
    				contador++;
    			}

    			if(atoi(argvv[0][1]) >= globalNumCommands)
    				validParam = 0;

    			if(!validParam){
    				printf("ERROR: Command not Found\n");
    				//Regresa la minishell a solicitar un comando
    				continue;
    			}else{
    				printf("Running command %s\n", argvv[0][1]);
    				
    				filev[0] = history[atoi(argvv[0][1])].filev[0];
    				filev[1] = history[atoi(argvv[0][1])].filev[1];
    				filev[2] = history[atoi(argvv[0][1])].filev[2];
    				bg = history[atoi(argvv[0][1])].bg;
    				num_commands = history[atoi(argvv[0][1])].num_commands;
    				argvv = history[atoi(argvv[0][1])].argvv;
    			}


    		}else{
    			perror("Numero de parametros incorrecto");
    			exit(-1);
    		}
    	}

    	//Valida la instruccion de usuario para iniciar "Mytime"
    	if(!strcmp(argvv[0][0], "mytime")){
    		if(argvv[0][1] == NULL && argvv[1] == NULL){
    			//Llama la funcion mytime si es correcto
    			mytime();

    			//Si el comando mytime fue el comando 20 borra el primer comando en el struct 
    			if(globalNumCommands >= 20)
    				free_command(&history[globalNumCommands%20]);
    			//Guarda el comando mytime en el struct
    			store_command(argvv, filev, bg, &history[globalNumCommands%20]);
    			globalNumCommands++;

    			//Regresa la minishell a solicitar un comando
    			continue;
    		}
    		else{
    			perror("Numero de parametros incorrecto");
    			exit(-1);
    		}
    	}

		//Valida en entrada de usuario mycd
    	if(!strcmp(argvv[0][0], "mycd")){
    		if(argvv[0][2] == NULL && argvv[1] == NULL){
    			mycd(argvv[0][1]);

    			//Si el comando mycd fue el comando 20 borra el primer comando en el struct. 
				if(globalNumCommands >= 20)
    				free_command(&history[globalNumCommands%20]);

    			//Guarda el comando mytime en el struct. 
    			store_command(argvv, filev, bg, &history[globalNumCommands%20]);
    			globalNumCommands++;

    			//Regresa la minishell a solicitar un comando.
    			continue;
    		}else{
    			perror("Numero de parametros incorrecto");
    			exit(-1);
    		}
		}

		//Valida la entrada de usuario por exit.
    	if(!strcmp(argvv[0][0], "exit")){
    		myExit(history, &globalNumCommands, first);
    	}

    	
    	/*
			
			Creacion de tuberias a partir de el numero de comandos introducidos

    	*/
    	switch(num_commands){
	    	case 3:
	    		pipe(p2);
	    	case 2:
	    		pipe(p1);
	    }



    	for (i = 0; i < num_commands; i++){

    		if(i == 1 && num_commands != 1){
    			close(p1[1]);	
    		}

    		if(i == 2 && num_commands != 1){
    			close(p2[1]);
    		}

    		// Creacion de hijos
      		pid = fork();

	      	switch(pid){

	      	case -1://Error
	          perror("Error al hacer fork");
	          break;
	        case 0://Hijo
	        	printf("Child %d\n", getpid());

	        	//Si existe mas de un comando, el primer comando
	          	//entra aqui.
	          if(i == 0 && num_commands != 1){

	          	//Redireccion de entrada y error
	          	for(j = 0; j < 3; j+=2){
	          		if(filev[j] != NULL){
	          			if((fdaux = open(filev[j], O_CREAT | O_RDWR, 00666)) == -1){
	          				perror("Error al abrir el fichero para redireccion");
	          			}else{
	          				close(j);
	          				dup(fdaux);
	          				close(fdaux);
	          			}
	          		}
	          	}



	          	//Redireccion de salidas

	          	close(1);
	          	dup(p1[1]);

	          	close(p1[1]);
	          	close(p1[0]);

	          	//Si existe la tuberia, se cierra
	          	if(p2[0] > 0){
	          		close(p2[0]);
	          		close(p2[1]);
	          	}

	          }
	          //Si es el segundo hijo
	          if(i == 1){
	          	close(0);
	          	dup(p1[0]);
	          	close(p1[0]);


	          	if(p2[0] > 0){
	          		close(1);
	          		dup(p2[1]);
	          		close(p2[1]);
	          		close(p2[0]);

	          		//Redireccion de error. 
	          		if(filev[2] != NULL){
	          			if((fdaux = open(filev[2], O_CREAT | O_RDWR, 00666)) == -1){
	          				perror("Error al abrir el fichero para redireccion");
	          				continue;
	          			}else{
	          				close(2);
	          				dup(fdaux);
	          				close(fdaux);
	          			}
          			}
	          	}
	          }


	          //Tercer hijo
	          if(i == 2){
	          	close(0);
	          	dup(p2[0]);
	          	close(p2[0]);

          		close(p1[0]);

	          }

	          //Ultimo hijo
	          /*Siempre se entra a esta condicion*/
	          if(i == num_commands - 1){
	          	if(num_commands == 1)//Si solo hay un comando, se realiza la redireccion de entrada.
	          		j = 0;
	          	else
	          		j = 1;

	          	for(; j < 3; j++){
	          		if(filev[j] != NULL){
	          			if((fdaux = open(filev[j], O_CREAT | O_RDWR, 00666)) == -1){
	          				perror("Error al abrir el fichero para redireccion");
	          			}else{
	          				close(j);
	          				dup(fdaux);
	          				close(fdaux);
	          			}
	          		}
	          	}
	          	
	          }

	         //Ejecucion del comando.
	         execvp(argvv[i][0], argvv[i]);
	         perror("");

	         exit(1);
	          

			}//fin switch
	   }//fin for numcommands


	
 		/*Ejecucion en foreground*/
	   //Espera bloqueante para el ultimo proceso hijo
	   	
		if(bg != 1){
				
				while(pid != wait(&status)){}
				printf("Wait child %d\n", pid);
	
			}
			   	/*Ejecucion en background*/
				//Espera no bloqueante
			else{

				waitpid(pid, &status, WNOHANG);
				printf("[%d]\n", pid);

				//Primer comando en background
				//Se crea el primer nodo 
				if(first == NULL){
					first = (node_t*) malloc(sizeof(node_t));
					last = first;
					last -> bgPid = pid;
					last -> next = NULL;
				}
				//En caso de que ya exista un proceso en background,
				//se aniade un nuevo nodo con el pid y un puntero al siguiente nodo. 
				else
					addNode(pid, last);


			}

		//Si el comando en foreground es correct, se guarda
	   if(WEXITSTATUS(status) == 0){

    		if(globalNumCommands >= 20)
    			free_command(&history[globalNumCommands%20]);

    		//Inicializar los punteros de myhistory para evitar errores por basura
    		//que se llegara a encontrar en la memoria. 
    		history[globalNumCommands%20].argvv = NULL;
    		history[globalNumCommands%20].filev[0] = NULL;
    		history[globalNumCommands%20].filev[1] = NULL;
    		history[globalNumCommands%20].filev[2] = NULL;
    		history[globalNumCommands%20].args = NULL;

    		//Se guardan los comandos en el arreglo historia.
    		store_command(argvv, filev, bg, &history[globalNumCommands%20]);
    		globalNumCommands++;
		}

		//Cierre definitivo de tuberias
		close(p1[0]);
		close(p2[0]);

	} //fin while 

	return 0;

} //end main

