/* Programa que combina datos de dos ficheros. */

/*
 Inclusión de liberias estandar y necesarias para el programa combine.c.
 Llamada al sistema OPEN está definida en #include <fcntl.h>.
 Llamada al sistema READ y CLOSE está definida en #include <unistd.h>.
 La función para calcular el tamaño del buffer está definida en #include <sys/stat.h>
 La constante definida para el modo de apertura en OPEN está definida en #include <sys/stat.h>
 */

#include "persona.h"
#include <stdio.h>
#include <fcntl.h>	/*open*/
#include <unistd.h>	/*read*/
#include <sys/stat.h>

int main(int argc, char *argv[]){
    
    /*
     Condiciones para manejo de errores en recepcion de parámetros,
     lectura y escritura de ficheros.
     */

	/*Comprobar el numero de parametros*/
	if(argc != 4){
		write(2, "Error combine recibe 4 parámetros\n", 35);
		return -1;
	}

	/*Comprobar tamaño ficheros*/
	struct stat buf;

	if(stat(argv[1], &buf) == -1){
		write(2, "Error. El fichero de entrada 1 no existe\n", 42);
		return -1;
	}
    /*
     En caso de que el buffer generado por la lectura de un fichero exceda la estructura definida en Persona.h, devuelve un error
     */
	if(buf.st_size % sizeof(Person) != 0){
		write(2, "Error. Primer archivo de entrada con estructura incorrecta\n", 60);
		return -1;
	}

	if(stat(argv[2], &buf) == -1){
		write(2, "Error. El fichero de entrada 2 no existe\n", 42);
		return -1;
	}
	if(buf.st_size % sizeof(Person) != 0){
		write(2, "Error. Segundo archivo de entrada con estructura incorrecta\n", 61);
		return -1;
	 }	

	/*Abrir el fichero de entrada 1*/
	int fd1 = open(argv[1], O_RDONLY);
	
	if(fd1 == -1){
		write(2, "Error al abrir el primer archivo de entrada\n", 45);
		return -1;
	}

	/*Abrir el fichero de entrada 2*/
	int fd2 = open(argv[2], O_RDONLY);
	
	if(fd2 == -1){
		write(2, "Error al abrir el segundo archivo de entrada\n", 46);
		return -1;
	}	

	/*Abrir el fichero de salida*/
	int fd3 = open(argv[3], O_CREAT|O_RDWR|O_TRUNC, S_IRWXU);
	
	if(fd3 == -1){
		write(2, "Error al abrir el archivo de salida\n", 37);
		return -1;
	}

	/*Punteros de ficheros*/
	int tamf1 = lseek(fd1, -sizeof(Person), SEEK_END);
	
	if(tamf1 < 0){
		write(2, "Error al reposicionar el puntero del fichero de entrada 1\n", 59);
		return -1;
	}

		
	
	int tamf2 = lseek(fd2, -sizeof(Person), SEEK_END);
	
	if(tamf2 < 0){
		write(2, "Error al reposicionar el puntero del fichero de entrada 2\n", 59);
		return -1;
	}

		
	
	/*Structs que funcionan de buffer*/
	Person p1;


	/*
     Bucle para leer e imprimir el archivo.
     Controla la lectura de ambos ficheros al mismo tiempo con la operacion módulo.
     Escribe en un tercer fichero si no se detectan errores con las varible errorWrite y
     errorRead
     */
	int errorRead = 0;
	int errorWrite = 0;
	int i = 0;
	while((tamf1 >= 0 || tamf2 >= 0) && errorRead >= 0 && errorWrite >= 0){
		
		if(i%2 == 0 && tamf1 >= 0){
			errorRead = read(fd1, &p1, sizeof(Person));
			errorWrite = write(fd3, &p1, sizeof(Person));
			tamf1 -= sizeof(Person);
			if(tamf1 >= 0)
				lseek(fd1, tamf1, SEEK_SET);
			
		}
		if(i%2 != 0 && tamf2 >= 0){
			errorRead = read(fd2, &p1, sizeof(Person));
			errorWrite = write(fd3, &p1, sizeof(Person));
			tamf2 -= sizeof(Person);
			if(tamf2 >= 0)
				lseek(fd2, tamf2, SEEK_SET);
		}
		i++;
	}
	
	while(close(fd1) == -1 && close(fd2) == -1 && close(fd3) == -1){}	

	if(errorRead == -1){
		write(2, "Error al leer de un archivo\n", 29);
		return -1;
	}
	if(errorWrite == -1){
		write(2, "Error al escribir en un archivo\n", 33);
		return -1;
	}

	return 0;
}

