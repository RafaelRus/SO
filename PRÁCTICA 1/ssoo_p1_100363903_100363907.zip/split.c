/* Programa que divide las personas del fichero de entrada según su rango de edad. */

/*
 Inclusión de liberias estandar y necesarias para el programa split.c.
 Llamada al sistema OPEN está definida en #include <fcntl.h>.
 Llamada al sistema READ y CLOSE está definida en #include <unistd.h>.
 La función para calcular el tamaño del buffer está definida en #include <sys/stat.h>
 La constante definida para el modo de apertura en OPEN está definida en #include <sys/stat.h>
 */

#include "persona.h"
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>	/*open*/
#include <unistd.h>	/*read*/
#include <sys/stat.h>	/*modo de open*/

int main(int argc, char *argv[]){
    
    /*
     Condiciones para manejo de errores en recepcion de parámetros,
     lectura y escritura de ficheros.
     */

	/*Comprobar el numero de parametros*/
	if(argc != 5){
		write(2, "Error split recibe 5 parámetros\n", 33);
		return -1;
	}
	
	/*
	 Comprobación para evitar parámetros erroneos.
	 Se comprueba que cada caracter que forme parte del parmáetro edad sea un número,
	 comprobando que esté dentro de la zona de números de la tabla ASCII.
	*/
	int i, validParam = 1;

	for(i = 0;i < (argv[2] - argv[1])-1 && validParam;i++){
		if(*(argv[1]+i) < 48 || *(argv[1]+i) > 57)
			validParam = 0;
	}
	
	if(!validParam){
		write(2, "Error. Parametro edad incorrecto\n", 34);
		return -1;
	}

	/*Comprobar tamaño fichero*/
	struct stat buf;

	if(stat(argv[2], &buf) == -1){
		write(2, "Error. El fichero no existe\n", 29);
		return -1;
	}
    /*
     En caso de que el buffer generado por la lectura de un fichero exceda la estructura definida en Persona.h, devuelve un error
     */
	if(buf.st_size % sizeof(Person) != 0){
		write(2, "Error. Archivo de entrada con estructura incorrecta\n", 53);
		return -1;
	 }	

	/*Abrir el fichero de entrada*/
	int fd1 = open(argv[2], O_RDONLY);
	
	if(fd1 == -1){
		write(2, "Error al abrir el archivo de entrada\n", 38);
		return -1;
	}
	
	/*Abrir o crear el fichero de salida para menores*/
	int fd2 = open(argv[3], O_CREAT|O_RDWR, S_IRWXU);
	
	if(fd2 == -1){
		write(2, "Error al abrir el archivo de salida para menores\n", 50);
		return -1;
	}
	
	if(lseek(fd2, 0, SEEK_END) < 0){
		write(2, "Error al reposicionar el puntero del fichero de salida 1\n", 58);
		return -1;

	}

	/*Abrir o crear el fichero de salida para mayores o iguales*/
	int fd3 = open(argv[4], O_CREAT|O_RDWR, S_IRWXU);
	
	if(fd3 == -1){
		write(2, "Error al abrir el archivo de salida para mayores o iguales\n", 60);
		return -1;
	}

	if(lseek(fd3, 0, SEEK_END) < 0){
		write(2, "Error al reposicionar el puntero del fichero de salida 2\n", 58);
		return -1;

	}

	/*Structs que funcionan de buffer*/
	Person p1;


	/*Bucle para leer e imprimir el archivo*/
	int finBucle = read(fd1, &p1, sizeof(Person));
	int wr1;

	while(finBucle > 0){
        /* 
         Comparación de edades a partir del atributo Person.age
         y escritura en el fichero correspondiente a partir del resultado de la 
         previa comparación.
         */
		if(p1.age < atoi(argv[1])){
			wr1 = write(fd2, &p1, sizeof(Person));
			
			if(wr1 == -1){
				write(2, "Error al escribir en el archivo\n", 33);
				finBucle = -1;
			}
		}else{
			wr1 = write(fd3, &p1, sizeof(Person));
			
			if(wr1 == -1){
				write(2, "Error al escribir en el archivo\n", 33);
				finBucle = -1;
			}
		}		
		if(finBucle != -1)
			finBucle = read(fd1, &p1, sizeof(Person));
	}
	
	while(close(fd1) == -1 && close(fd2) == -1 && close(fd3) == -1){}


	if(finBucle == -1)
		write(2, "Error al manipular el archivo\n", 31);
	

	return finBucle;
}
