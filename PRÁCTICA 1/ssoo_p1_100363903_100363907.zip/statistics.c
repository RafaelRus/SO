/*Programa que muestra las estadísticas por pantalla de un fichero de personas. */

/*
 Inclusión de liberias estandar y necesarias para el programa statistics.c.
 Llamada al sistema OPEN está definida en #include <fcntl.h>.
 Llamada al sistema READ y CLOSE está definida en #include <unistd.h>.
 La función para calcular el tamaño del buffer está definida en #include <sys/stat.h>
 La constante definida para el modo de apertura en OPEN está definida en #include <sys/stat.h>
 */

#include "persona.h"
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>

int main(int argc, char *argv[]){
    
    /*
     Condiciones para manejo de errores en recepcion de parámetros,
     lectura y escritura de ficheros.
     */

	/*Comprobar el numero de parametros*/
	if(argc != 2){
		write(2, "Error statistics recibe 2 parámetros\n", 38);
		return -1;
	}

	/*Comprobar tamaño fichero*/
	struct stat buf;

	if(stat(argv[1], &buf) == -1){
		write(2, "Error. El fichero no existe\n", 29);
		return -1;
	}
    /*
     En caso de que el buffer generado por la lectura de un fichero exceda la estructura definida en Persona.h, devuelve un error 
     */
	if(buf.st_size % sizeof(Person) != 0){
		write(2, "Error. Archivo con estructura incorrecta\n", 42);
		return -1;
	 }

	/*Abrir el fichero*/
	int fd = open(argv[1], O_RDONLY);
	
	if(fd == -1){
		write(2, "Error al abrir el archivo\n", 27);
		return -1;
	}
	
	/*Struct que funciona de buffer*/
	Person p;
	char caracteresDni[27] = {0};
	char valoresEdadCaracter[27] = {0};
	
	/*Bucle para leer y guardar los datos*/
	int finBucle = read(fd, &p, sizeof(Person));
	int numPersons = 0;
	int sumaEdad = 0;
	int sumaRenta = 0;

	while(finBucle > 0){
		sumaEdad += p.age;
		sumaRenta += p.salary;
		numPersons++;
		caracteresDni[p.id_ctrl-65]++;
		valoresEdadCaracter[p.id_ctrl-65] += p.age;

		finBucle = read(fd, &p, sizeof(Person));
	}

	int bestChar = 0;
	int i = 0;

    /*
     Bucle para leer todos los caracteres de diferenciación en el DNI
     en la esctructura Personas
     y calcular el más frecuente. 
     */	

	for(i = 1;i<27;i++){
		if(caracteresDni[i] > caracteresDni[bestChar])
			bestChar = i;
	}	

	printf("Renta media: %d \nEdad media: %d \nCaracter de control de DNI más frecuente:  %c \nEdad media para el caracter de control de DNI más frecuente: %d\n", sumaRenta/numPersons, sumaEdad/numPersons, bestChar+65, valoresEdadCaracter[bestChar]/caracteresDni[bestChar]);


	
	while(close(fd) == -1){}	

	if(finBucle == -1)
		write(2, "Error al leer el archivo\n", 26);
	

	return finBucle;
}

