/* Programa que filtra las personas con un determinado caracter de control de DNI.*/

/*
 Inclusión de liberias estandar y necesarias para el programa filter.c.
 Llamada al sistema OPEN está definida en #include <fcntl.h>.
 Llamada al sistema READ y CLOSE está definida en #include <unistd.h>.
 La función para calcular el tamaño del buffer está definida en #include <sys/stat.h>
 La constante definida para el modo de apertura en OPEN está definida en #include <sys/stat.h>
 */

#include "persona.h"
#include <stdio.h>
#include <fcntl.h>	/*open*/
#include <unistd.h>	/*read*/
#include <sys/stat.h>

int main(int argc, char *argv[]){
    
    /*
     Condiciones para manejo de errores en recepcion de parámetros,
     lectura y escritura de ficheros.
     */
    
	/*Comprobar el numero de parametros*/
	if(argc != 4){
		write(2, "Error filter recibe 4 parámetros\n", 34);
		return -1;
	}

	/*
	 Comprobación para evitar parámetros erroneos.
	 Sólo puede recibir una única letra mayúscula, contiguas en la tabla ASCII.
	 Todo valor fuera de ese grupo de la tabla se considera erroneo.
	*/
	if((argv[2] - argv[1])-1 != 1 && (*argv[1] < 65 || *argv[1] > 90)){
		write(2, "Error. Parametro caracter de control incorrecto\n", 49);
		return -1;
	}

	
	/*Comprobar tamaño fichero*/
	struct stat buf;

	if(stat(argv[2], &buf) == -1){
		write(2, "Error. El fichero no existe\n", 29);
		return -1;
	}
    /*
     En caso de que el buffer generado por la lectura de un fichero exceda la estructura definida en Persona.h, devuelve un error
     */
	if(buf.st_size % sizeof(Person) != 0){
		write(2, "Error. Archivo de entrada con estructura incorrecta\n", 53);
		return -1;
	 }

	/*Abrir el fichero de entrada*/
	int fd1 = open(argv[2], O_RDONLY);
	
	if(fd1 == -1){
		write(2, "Error al abrir el archivo de entrada\n", 38);
		return -1;
	}
	
	/*Abrir el fichero de salida*/
	int fd2 = open(argv[3], O_CREAT|O_RDWR|O_TRUNC, S_IRWXU);
	
	if(fd2 == -1){
		write(2, "Error al abrir el archivo de salida\n", 37);
		return -1;
	}	
	
	/*Struct que funciona de buffer*/
	Person p1;


	/*Bucle para leer e imprimir el archivo*/
	int finBucle = read(fd1, &p1, sizeof(Person));
	int wr;

    /* 
     Comparación del caracter introducido como parámetro por el usuario con el atributo
     Person.id_ctrl
     */
	while(finBucle > 0){
		if(p1.id_ctrl == *argv[1]){
			wr = write(fd2, &p1, sizeof(Person));
			
			if(wr == -1){
				write(2, "Error al escribir en el archivo\n", 33);
				finBucle = -1;
			}
		}
		if(finBucle != -1)
			finBucle = read(fd1, &p1, sizeof(Person));
	}
	
	while(close(fd1) == -1 && close(fd2) == -1){}	

	if(finBucle == -1)
		write(2, "Error al leer el archivo\n", 26);
	

	return finBucle;
}

